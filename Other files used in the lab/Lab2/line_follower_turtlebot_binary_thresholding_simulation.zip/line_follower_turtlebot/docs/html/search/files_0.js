var searchData=
[
  ['detect_2ecpp',['detect.cpp',['../detect_8cpp.html',1,'']]]
];
